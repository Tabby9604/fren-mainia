# some text

A rather unique HJSON mod created by Elixias. Features some things, some more things, and even things that explode in your face. (working on it)

Holy crap it's even used as the modding wiki's example.

Special thanks to Meep and others for handling the support for many things.

If you are here, you have found the incomplete and barely functional 7.0 port/0.8 alpha content overhaul. Much of the stuff here is unfinished.

**do NOT expect a functional mod yet. if you ask me to fix a bug, it will be ignored.**

---



















idk man this is a work of art (if you can call it that) made by someone going insane

talk to insane girl and recieve updates if you care: https://discord.gg/M3hm5z6nm6









































help
